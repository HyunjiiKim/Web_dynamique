<footer>
	<p>&copy; 2024 Fake Car Dealership. All Rights Reserved.</p>
	<p><a href="#privacy" style="color: #fff;">Privacy Policy</a> | <a href="#terms" style="color: #fff;">Terms of Service</a></p>
</footer>
