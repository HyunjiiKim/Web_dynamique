<?php
$current_page = '3';
include 'includes/header.php';
include 'includes/team_members.php';
?>

<?php include 'includes/footer.php'; ?>
</body>
</html>
